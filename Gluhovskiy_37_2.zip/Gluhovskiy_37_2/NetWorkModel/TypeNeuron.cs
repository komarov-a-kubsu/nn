﻿namespace Gluhovskiy_37_2.NetWorkModel
{
    public enum TypeNeuron
    {
        HiddenNeuron = 0,
        OutputNeuron = 1
#if DEBUG
            , InputNeuron = -1
#endif
    };
    public enum MemoryMode
    {
        INIT = 0,
        SET = 1,
        GET = 2
    };
    public enum NetworkMode
    {
        Train,
        Test,
        Demo
    };
}
