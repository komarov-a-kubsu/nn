﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Gluhovskiy_37_2.NetWorkModel
{
    public class Network
    {
        private InputLayer _inputLayer = null;
             private OutputLayer               _outputLayer = new OutputLayer(10, 32, TypeNeuron.OutputNeuron, nameof(_outputLayer));
        private HiddenLayer _hiddenLayer2 = new HiddenLayer(32, 73, TypeNeuron.HiddenNeuron, nameof(_hiddenLayer2));
        private HiddenLayer _hiddenLayer1 = new HiddenLayer(73, 15, TypeNeuron.HiddenNeuron, nameof(_hiddenLayer1));
        public double[] fact = new double[10];
        //средне знач энергии ош эпохи
        private double e_error_avr;//(energy error average)
        public double E_ERROR_AVR { get=>e_error_avr; set=>e_error_avr = value; }
        int numIterations = 500;
        public Network(NetworkMode networkMode)
        {
            _inputLayer=new InputLayer(networkMode);
            weightsInputHidden = new List<List<double>>();
            weightsHiddenOutput = new List<List<double>>();
            Random rand = new Random((int)DateTime.Now.Ticks);
            for (int i = 0; i < InputSize; ++i)
            {
                List<double> inputHiddenRow = new List<double>();
                for (int j = 0; j < HiddenSize; ++j)
                {
                    inputHiddenRow.Add(rand.NextDouble() - 0.5);
                }
                weightsInputHidden.Add(inputHiddenRow);
            }

            for (int i = 0; i < HiddenSize; ++i)
            {
                List<double> hiddenOutputRow = new List<double>();
                for (int j = 0; j < OutputSize; ++j)
                {
                    hiddenOutputRow.Add(rand.NextDouble() - 0.5);
                }
                weightsHiddenOutput.Add(hiddenOutputRow);
            }

            /// _hiddenLayer1
            //   _hiddenLayer2 
            // _outputLayer 

        }
        public void ForwardPass(Network net, double[] netInput)
        {
            net._hiddenLayer1.Data = netInput;
            net._hiddenLayer1.Recognaize(null, net._hiddenLayer2);
            net._hiddenLayer2.Recognaize(null, net._outputLayer);
            net._outputLayer.Recognaize(net, null);
        }
        //анонимные функции
        /// <summary>
        /// https://learn.microsoft.com/ru-ru/dotnet/csharp/language-reference/operators/lambda-expressions
        /// </summary>
        public Action<int, double> PrintXY { set; private get; }
        public Action Clear;
        /// <summary>
        /// int-size
        /// float x_min
        /// float x_max
        /// float y_min
        /// float y_max
        /// </summary>
        public Action<int,float,float,float,float> Init { set; private get; }
        public Action Print { set; get; }
        //Обучение
        public void Train(Network net)
        {
            int epoches = 1500;//кол-во эпох обучения(было 70)
            net._inputLayer = new InputLayer(NetworkMode.Train);//инициализация входного слоя для формирования обучающего множества
            double tmpSumError;//временная переменная суммы ошибок
            double[] errors;
            double[] tmp_gsums1,tmp_gsums2;//массивы локальныхградиентов 1 nad 2 hidden Lauyer
              Clear();
            Init(epoches,0,epoches,0,1);

            for(int k=0; k<epoches; k++)
            {
                e_error_avr = 0;
              
                for(int i = 0; i < net._inputLayer.Trainset.Length; i++)
                {
                    //прямой проход
                    ForwardPass(net, net._inputLayer.Trainset[i].Item1);
                    //вычисление ошибок по итерациям
                    tmpSumError = 0;
                    errors = new double[net.fact.Length];//переопределение масива сигнала ошибки
                    for(int x = 0; x < errors.Length; x++)
                    {
                        //дельтапраило
                        if (x==net._inputLayer.Trainset[i].Item2)
                        {
                            errors[x] = -(net.fact[x] - 1);//нахождение ошибки

                        }
                        else
                        {
                            errors[x] = -net.fact[x];//желаймый 0
                        }
                        tmpSumError+=errors[x]*errors[x]/2; 
                    }
                    //ошибка по эпох
                    e_error_avr += tmpSumError / errors.Length;//суммарное значение энергии ошибки эпох
                    //обратный проход и коррекция весов
                    tmp_gsums2 = net._outputLayer.BackWardPass(errors);//обратный проход для выходного слоя
                    tmp_gsums1 = net._hiddenLayer2.BackWardPass(tmp_gsums2);//предача градиента 2 скрыт слою
                    net._hiddenLayer1.BackWardPass(tmp_gsums1);

                }
                e_error_avr /= net._inputLayer.Trainset.Length;//среднне значение энергии ошибки 1 эпохи
                //написать код прередачи энергии ошибки эпохи на график и обновить график
                this.PrintXY(k, e_error_avr);
            }
            Print();
            net._inputLayer = null;//обнуление входного слоя
            //запись скорректированных весов в файл
            net._hiddenLayer1.WeightInitialize(MemoryMode.SET, net._hiddenLayer1.pathFileWeights);
            net._hiddenLayer2.WeightInitialize(MemoryMode.SET, net._hiddenLayer2.pathFileWeights);
            net._outputLayer.WeightInitialize(MemoryMode.SET, net._outputLayer.pathFileWeights);
        }

        private const int InputSize = 15;  // входной слой для 15 пикселей
        private const int HiddenSize = 10; // скрытый слой
        private const int OutputSize = 10; // выходной слой для 10 цифр

        private List<List<double>> weightsInputHidden;
        private List<List<double>> weightsHiddenOutput;

        public List<double> Predict(List<int> input)
        {
            List<double> hiddenLayer = new List<double>(new double[HiddenSize]);
            List<double> outputLayer = new List<double>(new double[OutputSize]);


            for (int i = 0; i < HiddenSize; ++i)
            {
                double sum = 0;
                for (int j = 0; j < InputSize; ++j)
                {
                    sum += input[j] * weightsInputHidden[j][i];
                }
                hiddenLayer[i] = Sigmoid(sum);
            }


            for (int i = 0; i < OutputSize; ++i)
            {
                double sum = 0;
                for (int j = 0; j < HiddenSize; ++j)
                {
                    sum += hiddenLayer[j] * weightsHiddenOutput[j][i];
                }
                outputLayer[i] = Sigmoid(sum);
            }

            return outputLayer;
        }

        public double CalculateError(List<double> predicted, int targetDigit)
        {
            double error = 0.0;
            for (int i = 0; i < OutputSize; ++i)
            {
                double target = (i == targetDigit) ? 1.0 : 0.0;
                error += Math.Pow(target - predicted[i], 2);
            }
            return 0.5 * error;
        }

        public double TrainEpoch(List<List<int>> inputs, List<int> targets, double learningRate)
        {
            double totalError = 0.0;

            for (int i = 0; i < inputs.Count; ++i)
            {
                List<int> input = inputs[i];
                int targetDigit = targets[i];


                Trainn(input, targetDigit, learningRate);

                List<double> output = Predict(input);

                double error = CalculateError(output, targetDigit);
                totalError += error;
            }

            return totalError;
        }


        public void Trainn(List<int> input, int targetDigit, double learningRate)
        {
            List<double> hiddenLayer = new List<double>(new double[HiddenSize]);
            List<double> outputLayer = new List<double>(new double[OutputSize]);

            for (int i = 0; i < HiddenSize; ++i)
            {
                double sum = 0;
                for (int j = 0; j < InputSize; ++j)
                {
                    sum += input[j] * weightsInputHidden[j][i];
                }
                hiddenLayer[i] = Sigmoid(sum);
            }


            for (int i = 0; i < OutputSize; ++i)
            {
                double sum = 0;
                for (int j = 0; j < HiddenSize; ++j)
                {
                    sum += hiddenLayer[j] * weightsHiddenOutput[j][i];
                }
                outputLayer[i] = Sigmoid(sum);
            }


            List<double> outputErrors = new List<double>(new double[OutputSize]);
            for (int i = 0; i < OutputSize; ++i)
            {
                outputErrors[i] = (i == targetDigit) ? (1 - outputLayer[i]) : (-outputLayer[i]);
            }

            List<double> outputDeltas = new List<double>(new double[OutputSize]);
            for (int i = 0; i < OutputSize; ++i)
            {
                outputDeltas[i] = outputErrors[i] * SigmoidDerivative(outputLayer[i]);
            }


            for (int i = 0; i < HiddenSize; ++i)
            {
                for (int j = 0; j < OutputSize; ++j)
                {
                    weightsHiddenOutput[i][j] += hiddenLayer[i] * outputDeltas[j] * learningRate;
                }
            }

            List<double> hiddenErrors = new List<double>(new double[HiddenSize]);
            for (int i = 0; i < HiddenSize; ++i)
            {
                double sum = 0;
                for (int j = 0; j < OutputSize; ++j)
                {
                    sum += weightsHiddenOutput[i][j] * outputDeltas[j];
                }
                hiddenErrors[i] = sum * SigmoidDerivative(hiddenLayer[i]);
            }

            List<double> hiddenDeltas = new List<double>(new double[HiddenSize]);
            for (int i = 0; i < HiddenSize; ++i)
            {
                hiddenDeltas[i] = hiddenErrors[i] * SigmoidDerivative(hiddenLayer[i]);
            }

            for (int i = 0; i < InputSize; ++i)
            {
                for (int j = 0; j < HiddenSize; ++j)
                {
                    weightsInputHidden[i][j] += input[i] * hiddenDeltas[j] * learningRate;
                }
            }
        }

        public void SaveModel(string filename)
        {

            using (StreamWriter file = new StreamWriter(filename))
            {
                for (int i = 0; i < InputSize; ++i)
                {
                    for (int j = 0; j < HiddenSize; ++j)
                    {
                        file.WriteLine(weightsInputHidden[i][j]);
                    }
                }

                for (int i = 0; i < HiddenSize; ++i)
                {
                    for (int j = 0; j < OutputSize; ++j)
                    {
                        file.WriteLine(weightsHiddenOutput[i][j]);
                    }
                }
            }
        }

        public void LoadModel(string filename)
        {

            using (StreamReader file = new StreamReader(filename))
            {
                for (int i = 0; i < InputSize; ++i)
                {
                    for (int j = 0; j < HiddenSize; ++j)
                    {
                        weightsInputHidden[i][j] = double.Parse(file.ReadLine());
                    }
                }

                for (int i = 0; i < HiddenSize; ++i)
                {
                    for (int j = 0; j < OutputSize; ++j)
                    {
                        weightsHiddenOutput[i][j] = double.Parse(file.ReadLine());
                    }
                }
            }
        }

        private void InitializeWeights()
        {

            Random rand = new Random((int)DateTime.Now.Ticks);


            for (int i = 0; i < InputSize; ++i)
            {
                for (int j = 0; j < HiddenSize; ++j)
                {
                    weightsInputHidden[i][j] = rand.NextDouble() - 0.5;
                }
            }

            for (int i = 0; i < HiddenSize; ++i)
            {
                for (int j = 0; j < OutputSize; ++j)
                {
                    weightsHiddenOutput[i][j] = rand.NextDouble() - 0.5;
                }
            }
        }

        private double Sigmoid(double x)
        {
            return 1.0 / (1.0 + Math.Exp(-x));
        }

        private double SigmoidDerivative(double x)
        {
            return x * (1 - x);
        }
        public List<double> TrainNetwork(List<List<int>> inputs, List<int> targets)
        {
            /*List<int> targets = new List<int>
            {
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
                5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
                7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
                8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
                9, 9, 9, 9, 9, 9, 9, 9, 9, 9
            };*/

            double learningRate = 0.1;

            List<double> averageErrors = new List<double>();

            for (int i = 0; i < numIterations; i++)
            {
                double epochError = TrainEpoch(inputs, targets, learningRate);
                double averageError = epochError / inputs.Count;
                this.PrintXY(i, averageError);
            }

            SaveModel("model.txt");

            return averageErrors;
        }
    }
}
