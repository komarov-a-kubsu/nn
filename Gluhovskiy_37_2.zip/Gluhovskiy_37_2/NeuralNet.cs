﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _Gluhovskiy_37_2
{
    internal class NeuralNet
    {
        private const int InputSize = 15;  // входной слой для 15 пикселей
        private const int HiddenSize = 10; // скрытый слой
        private const int OutputSize = 10; // выходной слой для 10 цифр

        private List<List<double>> weightsInputHidden;
        private List<List<double>> weightsHiddenOutput;

        public NeuralNet()
        {

            weightsInputHidden = new List<List<double>>();
            weightsHiddenOutput = new List<List<double>>();
            Random rand = new Random((int)DateTime.Now.Ticks);
            for (int i = 0; i < InputSize; ++i)
            {
                List<double> inputHiddenRow = new List<double>();
                for (int j = 0; j < HiddenSize; ++j)
                {
                    inputHiddenRow.Add(rand.NextDouble() - 0.5);
                }
                weightsInputHidden.Add(inputHiddenRow);
            }

            for (int i = 0; i < HiddenSize; ++i)
            {
                List<double> hiddenOutputRow = new List<double>();
                for (int j = 0; j < OutputSize; ++j)
                {
                    hiddenOutputRow.Add(rand.NextDouble() - 0.5);
                }
                weightsHiddenOutput.Add(hiddenOutputRow);
            }
        }

        // Forward pass
        public List<double> Predict(List<int> input)
        {
            List<double> hiddenLayer = new List<double>(new double[HiddenSize]);
            List<double> outputLayer = new List<double>(new double[OutputSize]);


            for (int i = 0; i < HiddenSize; ++i)
            {
                double sum = 0;
                for (int j = 0; j < InputSize; ++j)
                {
                    sum += input[j] * weightsInputHidden[j][i];
                }
                hiddenLayer[i] = Sigmoid(sum);
            }


            for (int i = 0; i < OutputSize; ++i)
            {
                double sum = 0;
                for (int j = 0; j < HiddenSize; ++j)
                {
                    sum += hiddenLayer[j] * weightsHiddenOutput[j][i];
                }
                outputLayer[i] = Sigmoid(sum);
            }

            return outputLayer;
        }

        public double CalculateError(List<double> predicted, int targetDigit)
        {
            double error = 0.0;
            for (int i = 0; i < OutputSize; ++i)
            {
                double target = (i == targetDigit) ? 1.0 : 0.0;
                error += Math.Pow(target - predicted[i], 2);
            }
            return 0.5 * error;
        }

        public double TrainEpoch(List<List<int>> inputs, List<int> targets, double learningRate)
        {
            double totalError = 0.0;

            for (int i = 0; i < inputs.Count; ++i)
            {
                List<int> input = inputs[i];
                int targetDigit = targets[i];


                Train(input, targetDigit, learningRate);

                List<double> output = Predict(input);

                double error = CalculateError(output, targetDigit);
                totalError += error;
            }

            return totalError;
        }


        public void Train(List<int> input, int targetDigit, double learningRate)
        {
            List<double> hiddenLayer = new List<double>(new double[HiddenSize]);
            List<double> outputLayer = new List<double>(new double[OutputSize]);

            for (int i = 0; i < HiddenSize; ++i)
            {
                double sum = 0;
                for (int j = 0; j < InputSize; ++j)
                {
                    sum += input[j] * weightsInputHidden[j][i];
                }
                hiddenLayer[i] = Sigmoid(sum);
            }


            for (int i = 0; i < OutputSize; ++i)
            {
                double sum = 0;
                for (int j = 0; j < HiddenSize; ++j)
                {
                    sum += hiddenLayer[j] * weightsHiddenOutput[j][i];
                }
                outputLayer[i] = Sigmoid(sum);
            }


            List<double> outputErrors = new List<double>(new double[OutputSize]);
            for (int i = 0; i < OutputSize; ++i)
            {
                outputErrors[i] = (i == targetDigit) ? (1 - outputLayer[i]) : (-outputLayer[i]);
            }

            List<double> outputDeltas = new List<double>(new double[OutputSize]);
            for (int i = 0; i < OutputSize; ++i)
            {
                outputDeltas[i] = outputErrors[i] * SigmoidDerivative(outputLayer[i]);
            }


            for (int i = 0; i < HiddenSize; ++i)
            {
                for (int j = 0; j < OutputSize; ++j)
                {
                    weightsHiddenOutput[i][j] += hiddenLayer[i] * outputDeltas[j] * learningRate;
                }
            }

            List<double> hiddenErrors = new List<double>(new double[HiddenSize]);
            for (int i = 0; i < HiddenSize; ++i)
            {
                double sum = 0;
                for (int j = 0; j < OutputSize; ++j)
                {
                    sum += weightsHiddenOutput[i][j] * outputDeltas[j];
                }
                hiddenErrors[i] = sum * SigmoidDerivative(hiddenLayer[i]);
            }

            List<double> hiddenDeltas = new List<double>(new double[HiddenSize]);
            for (int i = 0; i < HiddenSize; ++i)
            {
                hiddenDeltas[i] = hiddenErrors[i] * SigmoidDerivative(hiddenLayer[i]);
            }

            for (int i = 0; i < InputSize; ++i)
            {
                for (int j = 0; j < HiddenSize; ++j)
                {
                    weightsInputHidden[i][j] += input[i] * hiddenDeltas[j] * learningRate;
                }
            }
        }

        public void SaveModel(string filename)
        {

            using (StreamWriter file = new StreamWriter(filename))
            {
                for (int i = 0; i < InputSize; ++i)
                {
                    for (int j = 0; j < HiddenSize; ++j)
                    {
                        file.WriteLine(weightsInputHidden[i][j]);
                    }
                }

                for (int i = 0; i < HiddenSize; ++i)
                {
                    for (int j = 0; j < OutputSize; ++j)
                    {
                        file.WriteLine(weightsHiddenOutput[i][j]);
                    }
                }
            }
        }

        public void LoadModel(string filename)
        {

            using (StreamReader file = new StreamReader(filename))
            {
                for (int i = 0; i < InputSize; ++i)
                {
                    for (int j = 0; j < HiddenSize; ++j)
                    {
                        weightsInputHidden[i][j] = double.Parse(file.ReadLine());
                    }
                }

                for (int i = 0; i < HiddenSize; ++i)
                {
                    for (int j = 0; j < OutputSize; ++j)
                    {
                        weightsHiddenOutput[i][j] = double.Parse(file.ReadLine());
                    }
                }
            }
        }

        private void InitializeWeights()
        {

            Random rand = new Random((int)DateTime.Now.Ticks);


            for (int i = 0; i < InputSize; ++i)
            {
                for (int j = 0; j < HiddenSize; ++j)
                {
                    weightsInputHidden[i][j] = rand.NextDouble() - 0.5;
                }
            }

            for (int i = 0; i < HiddenSize; ++i)
            {
                for (int j = 0; j < OutputSize; ++j)
                {
                    weightsHiddenOutput[i][j] = rand.NextDouble() - 0.5;
                }
            }
        }

        private double Sigmoid(double x)
        {
            return 1.0 / (1.0 + Math.Exp(-x));
        }

        private double SigmoidDerivative(double x)
        {
            return x * (1 - x);
        }
        public Action<int, double> PrintXY { set; private get; }
        public Action Clear;
        /// <summary>
        /// int-size
        /// float x_min
        /// float x_max
        /// float y_min
        /// float y_max
        /// </summary>
        public Action<int, float, float, float, float> Init { set; private get; }
        public Action Print { set; get; }
        public List<double> TrainNetwork(List<List<int>> inputs, List<int> targets)
        {
            /*List<int> targets = new List<int>
            {
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
                5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
                7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
                8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
                9, 9, 9, 9, 9, 9, 9, 9, 9, 9
            };*/

            int numIterations = 1000;
            double learningRate = 0.1;

            List<double> averageErrors = new List<double>();

            for (int i = 0; i < numIterations; i++)
            {
                double epochError = TrainEpoch(inputs, targets, learningRate);
                double averageError = epochError / inputs.Count;
                this.PrintXY(i, averageError);
            }

            SaveModel("model.txt");

            return averageErrors;
        }
    }
}
